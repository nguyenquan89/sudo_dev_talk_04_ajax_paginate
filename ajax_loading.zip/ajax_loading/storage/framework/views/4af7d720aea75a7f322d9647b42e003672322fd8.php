<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Html Template</title>
	<!-- style -->
	<link rel="stylesheet" href="assets/libs/font-awesome/font-awesome.min.css">
	<link rel="stylesheet" href="assets/libs/owl-carousel/owl.carousel.min.css">
	<link rel="stylesheet" href="assets/css/style.min.css">
	<!-- script head -->
	<script type="text/javascript" src="assets/libs/js/jquery.min.js"></script>
	<script type="text/javascript" src="assets/libs/owl-carousel/owl.carousel.min.js"></script>
	<script type="text/javascript" src="assets/js/functions.min.js"></script>
</head>
<body>
	<header class="header">
		<div class="container"></div>
	</header>

	<?php echo $__env->yieldContent('content'); ?>

	<footer class="fooer">
		<div class="container"></div>
	</footer>

	<div id="loading_box"><div id="loading_image"></div></div>
	<section class="progress-box"><div class="progress-run"></div></section>
	
	<!-- script foot -->
	<script type="text/javascript" src="assets/js/core.min.js"></script>
	<script type="text/javascript" src="assets/js/main.min.js"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\ajax_loading\resources\views/web/layouts/app.blade.php ENDPATH**/ ?>