<?php if(isset($data) && !empty($data)): ?>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="item">
	<div class="item-image image-3-2">
		<a href="<?php echo e($item->geturl()); ?>"><img src="<?php echo e($item->getImage()); ?>" alt=""></a>
	</div>
	<div class="item-info">
		<div class="item-info__title">
			<h3><a href="<?php echo e($item->geturl()); ?>"><?php echo e($item->getName()); ?></a></h3>
		</div>
		<div class="item-info__list">
			<ul>
				<li><i class="fa fa-clock-o"></i> <?php echo e($item->getTime()); ?></li>
				<li><i class="fa fa-bars"></i> SudoDC</li>
			</ul>
		</div>
		<div class="item-info__desc"><?php echo e($item->getDesc()); ?></div>
	</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\ajax_loading\resources\views/web/posts/item.blade.php ENDPATH**/ ?>