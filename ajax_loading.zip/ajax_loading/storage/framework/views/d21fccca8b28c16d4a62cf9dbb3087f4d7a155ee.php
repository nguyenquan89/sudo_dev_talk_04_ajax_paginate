

<?php $__env->startSection('content'); ?>

<main class="main">
	<div class="container">
		<div class="posts">
			<div class="title">Tin tức</div>
			<div class="posts-list">
				
				<?php echo $__env->make('web.posts.item', ['data' => $posts], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				
			</div>
			
			<?php echo $__env->make('web.layouts.paginate', ['data' => $posts], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		</div>
	</div>
</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ajax_loading\resources\views/web/home.blade.php ENDPATH**/ ?>