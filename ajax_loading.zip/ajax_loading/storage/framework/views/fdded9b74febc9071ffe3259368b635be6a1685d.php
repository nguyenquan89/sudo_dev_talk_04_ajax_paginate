<?php if(isset($data) && !empty($data)): ?>
<div class="paginate-box">
	<?php echo e($data->appends(Request()->all())->links()); ?>

</div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\ajax_loading\resources\views/web/layouts/paginate.blade.php ENDPATH**/ ?>