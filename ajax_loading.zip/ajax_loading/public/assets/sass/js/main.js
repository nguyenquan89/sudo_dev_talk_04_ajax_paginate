$(document).ready(function() {
	$('body').on('click', '.paginate-box a.page-link', function(e) {
		e.preventDefault();
		href = $(this).attr('href');
		loadAjaxGet(href, {
	        beforeSend: function(){},
	        success:function(result){
	        	$('.posts-list').html(result.html);
	        	$('.paginate-box').html(result.pagiate);

	        	updateUrl(href);
	        },
	        error: function (error) {}
	    }, 'progress');
	});
});