<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Post extends Model
{
    public function geturl() {
    	return 'javascript:;';
    }

    public function getName() {
    	return $this->name;
    }

    public function getImage($size='') {
    	return getImage($this->image, $size);
    }

    public function getTime($format='d/m/Y') {
    	return $this->created_at->format($format);
    }

    public function getDesc($num = 200) {
    	return cutString(removeHTML($this->detail), $num);
    }
}
