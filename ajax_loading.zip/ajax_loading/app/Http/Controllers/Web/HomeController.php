<?php

namespace App\Http\Controllers\Web;

use Illuminate\Http\Request;
use App\Post;
class HomeController extends Controller
{
    public function index(Request $request) {
    	$posts = Post::paginate(4);
    	if ($request->ajax()) {
    		$html = view('web.posts.item')->with([
    			'data' => $posts
    		])->render();
    		$pagiate = $posts->appends(Request()->all())->links()->toHtml();
    		return [
    			'html' => $html,
    			'pagiate' => $pagiate
    		];
    	} else {
    		return view('web.home', compact('posts'));
    	}
    }
}
