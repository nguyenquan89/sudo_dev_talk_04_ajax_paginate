<?php

use Illuminate\Database\Seeder;

class PostTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('posts')->truncate();
        $data = config('defaultData');
        $id = 1;
        for ($i=0; $i < 10; $i++) {
            $post = [];
            for ($j=0; $j < 10; $j++) {
                $id++; 
                $name = $i.' '.$data['title'];
                $rand = rand(1,17);
                $rand = ($rand < 10)? '0'.$rand : $rand;
                $post[] = [
                    'name' => $name,
                    'slug' => str_slug($name),
                    'image' => './assets/img/posts/anh'.$rand.'.jpg',
                    'detail' => $data['detail'],
                    'status' => 1,
                    'created_at' => date('Y-m-d H:i:s'),
                    'updated_at' => date('Y-m-d H:i:s'),
                ];
            }
            DB::table('posts')->insert($post);
        }
    }
}
