<?php 

return [
	'title' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.',
	'detail' => '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsa consequatur non dignissimos quod vitae unde reiciendis impedit distinctio assumenda, dicta id similique in est totam ad nisi! Sit, adipisci, facilis!</p>
		<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsa consequatur non dignissimos quod vitae unde reiciendis impedit distinctio assumenda, dicta id similique in est totam ad nisi! Sit, adipisci, facilis!</p>
		<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsa consequatur non dignissimos quod vitae unde reiciendis impedit distinctio assumenda, dicta id similique in est totam ad nisi! Sit, adipisci, facilis!</p>',
];