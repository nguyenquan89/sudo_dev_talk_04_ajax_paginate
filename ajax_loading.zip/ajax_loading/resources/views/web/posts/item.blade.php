@if (isset($data) && !empty($data))
@foreach ($data as $item)
<div class="item">
	<div class="item-image image-3-2">
		<a href="{{$item->geturl()}}"><img src="{{$item->getImage()}}" alt=""></a>
	</div>
	<div class="item-info">
		<div class="item-info__title">
			<h3><a href="{{$item->geturl()}}">{{$item->getName()}}</a></h3>
		</div>
		<div class="item-info__list">
			<ul>
				<li><i class="fa fa-clock-o"></i> {{$item->getTime()}}</li>
				<li><i class="fa fa-bars"></i> SudoDC</li>
			</ul>
		</div>
		<div class="item-info__desc">{{$item->getDesc()}}</div>
	</div>
</div>
@endforeach
@endif