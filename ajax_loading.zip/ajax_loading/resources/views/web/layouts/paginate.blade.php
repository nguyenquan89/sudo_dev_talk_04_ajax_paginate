@if (isset($data) && !empty($data))
<div class="paginate-box">
	{{$data->appends(Request()->all())->links()}}
</div>
@endif