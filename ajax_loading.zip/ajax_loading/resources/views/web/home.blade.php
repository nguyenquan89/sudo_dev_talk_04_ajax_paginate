@extends('web.layouts.app')

@section('content')

<main class="main">
	<div class="container">
		<div class="posts">
			<div class="title">Tin tức</div>
			<div class="posts-list">
				
				@include('web.posts.item', ['data' => $posts])
				
			</div>
			
			@include('web.layouts.paginate', ['data' => $posts])
		</div>
	</div>
</main>

@endsection